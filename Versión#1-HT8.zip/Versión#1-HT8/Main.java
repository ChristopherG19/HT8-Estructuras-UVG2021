/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * HT8-Sistema de Hospital
 * @author Christopher García - 20541
 * @version 1
 * Se tomaron referencias de ejemplos vistos en clase y material de apoyo
 */
/**
 * Imports
 */
import java.util.*;
import java.io.*;

public class Main {
    
    public static void main(String[] args) {
    
      System.out.println("|---------------------------------|");
      System.out.println("|       Hospital Bienaventura     |");
      System.out.println("|---------------------------------|");

      System.out.println("Tengo entendido que necesitas ver los registros");

      VectorHeap<Paciente> VH = leerArchivo();
      System.out.println();
      System.out.println("Registro de emergencias");
      VH.OrdenCasos();  

    }

  /**
  * Método leerArchivo
  * Se lee el contenido del archivo y se guarda en un ArrayList
  * @param nombreArchivo: Recibe el nombre del archivo 
  * @return: Arraylist con las lineas del archivo
  */
  public static VectorHeap<Paciente> leerArchivo(){

    VectorHeap<Paciente> VH = new VectorHeap<Paciente>();

    try {
      
      File archivo = new File("Pacientes.txt");
      Scanner lectorarchivo = new Scanner(archivo);

      while(lectorarchivo.hasNextLine()){

        String informacion = lectorarchivo.nextLine();
        String[] registros = informacion.split(", ");
        Paciente NuevoIngreso = new Paciente(registros[0], registros[1], registros[2]);
        VH.add(NuevoIngreso);
      }

      lectorarchivo.close();

    } catch (Exception e) {
      System.out.println("Ha ocurrido un error con la lectura del archivo de registros");
      System.exit(1);
    }
    return VH;
  }
}
