public class Paciente implements Comparable<Paciente>{

    private String Nombre;
    private String Caso;
    private String Urgencia;
    private int UrgenciaFinal;

    public Paciente(String nom, String cas, String urg){
        this.Nombre = nom;
        this.Caso = cas;
        this.Urgencia = urg;
        UrgenciaFinal = this.CharToAscii(urg);
    }

    private int CharToAscii(String urg){
        final char urgenciaValue = urg.charAt(0);
        final int urgenciaAscii = (int)urgenciaValue;
        return (urgenciaAscii-64);
    }

    public String getNombre() {
        return Nombre;
    }

    public String getCaso() {
        return Caso;
    }

    public String getUrgencia() {
        return Urgencia;
    }

    public int getUrgenciaFinal() {
        return UrgenciaFinal;
    }

    @Override
    public int compareTo(Paciente o) {
        return (this.UrgenciaFinal - o.getUrgenciaFinal());
    }
    
    @Override
    public String toString() {
        return "|--> Nombre: " + Nombre + " | Caso: " + Caso + " | Urgencia de tipo: " + Urgencia + "\n";
    }

}
