import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class JUnit {

    /**
     * Test que permite comprobar los métodos para agregar y remover datos 
     * del VectorHeap
     */
    @Test
    public void Test1(){

        /**
         * Se crea un vectorheap de integers (para facilidad del test)
         */
        VectorHeap<Integer> vectorHeap = new VectorHeap<>();

        /**
         * Se comprueba que esta vacio, luego se agregan 3 valores
         * y se comprueba que el tamaño del vectorheap se de 3 también.
         * Se eliminan los valores comprobando que se eliminaron con el tamaño
         * del vectorheap y finalmente se comprueba que ya no hay elementos
         * 
         * Se imprimen mensajes para llevar un control de lo que sucede
         */
        assertEquals(vectorHeap.isEmpty(), true);
        System.out.println("Se comprobo que no habia valores");
        vectorHeap.add(1);
        System.out.println("Se agrego el valor 1");
        vectorHeap.add(2);
        System.out.println("Se agrego el valor 2");
        vectorHeap.add(3);
        System.out.println("Se agrego el valor 3");
        assertEquals(vectorHeap.size(), 3);
        System.out.println("Se comprobo que habian tres valores agregados");
        vectorHeap.remove();
        System.out.println("Se elimino un valor");
        assertEquals(vectorHeap.size(), 2);
        System.out.println("Se comprobo que habian dos valores agregados porque uno se elimino");
        vectorHeap.remove();
        System.out.println("Se elimino un valor");
        vectorHeap.remove();
        System.out.println("Se elimino un valor");
        assertEquals(vectorHeap.isEmpty(), true);
        System.out.println("Se comprobo que no habia valores");

    }

}
