/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * HT8-Sistema de Hospital
 * @author Christopher García - 20541
 * @version 3
 * Se tomaron referencias de ejemplos vistos en clase y material de apoyo
 */
/**
 * Clase Paciente que implementa la interfaz comparable
 */
public class Paciente implements Comparable<Paciente>{

    /**
     * Parámetros
     */
    private String Nombre;
    private String Caso;
    private String Urgencia;
    private int UrgenciaFinal;

    /**
     * Constructor
     * @param nom: Nombre del paciente
     * @param cas: Caso del paciente
     * @param urg: Nivel de urgencia del caso
     */
    public Paciente(String nom, String cas, String urg){
        this.Nombre = nom;
        this.Caso = cas;
        this.Urgencia = urg;
        UrgenciaFinal = this.CharToAscii(urg);
    }

    /** 
     * Método que convierte el nivel de urgencia en números para un mayor control y facilitar el manejo
     * @param urg: Urgencia del caso
     * @return int: Equivalente en números basándose en código Ascii
     */
    private int CharToAscii(String urg){
        final char urgenciaValue = urg.charAt(0);
        final int urgenciaAscii = (int)urgenciaValue;
        return (urgenciaAscii-64);
    }

    /** 
     * Getter para obtener el nombre del paciente
     * @return String: nombre del paciente
     */
    public String getNombre() {
        return Nombre;
    }

    /** 
     * Getter para obtener el caso del paciente
     * @return String: caso del paciente
     */
    public String getCaso() {
        return Caso;
    }

    /** 
     * Getter para obtener la urgencia del caso
     * @return String: urgencia del caso
     */
    public String getUrgencia() {
        return Urgencia;
    }

    /** 
     * Getter para obtener la urgencia del caso en números
     * @return int: Equivalente de la urgencia en número
     */
    public int getUrgenciaFinal() {
        return UrgenciaFinal;
    }

    /** 
     * Comparador de las urgencias de dos pacientes
     * @param o: Paciente
     * @return int
     */
    @Override
    public int compareTo(Paciente o) {
        return (this.UrgenciaFinal - o.getUrgenciaFinal());
    }
    
    /**
     * Método toString 
     * @return String
     */
    @Override
    public String toString() {
        return "|--> Nombre: " + Nombre + " | Caso: " + Caso + " | Urgencia de tipo: " + Urgencia + "\n";
    }

}
