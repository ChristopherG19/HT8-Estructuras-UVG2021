/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * HT8-Sistema de Hospital
 * @author Christopher García - 20541
 * @version 3
 * Se tomaron referencias de ejemplos vistos en clase y material de apoyo
 */
/**
 * Imports
 */
import java.util.*;
import java.io.*;

/**
 * Clase main
 */
public class Main {
    
    /**
     * Inicio del programa
     * @param args
     */
    public static void main(String[] args) {
    
      /**
       * Scanner para poder leer las opciones que escoja el usuario
       */
      Scanner scan = new Scanner(System.in);

      /**
       * Inicio del programa, impresion de mensajes informativos
       */
      System.out.println("\n\t\t|---------------------------------|");
      System.out.println("\t\t|       Hospital Bienaventura     |");
      System.out.println("\t\t|---------------------------------|\n");

      System.out.println("Tengo entendido que necesitas ver los registros");
      System.out.println("Necesito una eleccion del tipo de proceso que se utilizara");
      System.out.println();

      /**
       * Ciclo While que se ejecuta hasta que el usuario decida salir
       * En este ciclo el usuario puede escoger que tipo de implementación quiere observar
       */
      boolean verificador = true;
      try {
        while (verificador){
          System.out.println("\t\t\nTipos de procesos\n");
          System.out.println("1) Implementando PriorityQueue con VectorHeap");
          System.out.println("2) Implementando PriorityQueue con JCF");
          System.out.println("3) Salir\n");
          System.out.print("Tipo de proceso: ");
          String opcion = scan.nextLine();

          /**
           * Si escoge la opción 1, el programa muestra los registros
           * ordenados dependiendo de su urgencia/prioridad cumpliendo
           * con la implementación de la interfaz y clase
           * proporcionadas en clase
           */
          if (opcion.equals("1")){
            VectorHeap<Paciente> VH = leerArchivo();
            System.out.println();
            System.out.println("Registro de emergencias");
            VH.OrdenCasos();
            System.out.println();

          /**
           * Si escoge la opción 2, el programa muestra los registros
           * ordenados dependiendo de su urgencia/prioridad cumpliendo
           * con la implementación de PriorityQueue del JCF
           */
          } else if (opcion.equals("2")){
            PriorityQueue<Paciente> pQueue = new PriorityQueue<Paciente>();
            try {
      
              File archivo = new File("Pacientes.txt");
              Scanner lectorarchivo = new Scanner(archivo);
        
              while(lectorarchivo.hasNextLine()){
        
                String informacion = lectorarchivo.nextLine();
                String[] registros = informacion.split(", ");
                Paciente NuevoIngreso = new Paciente(registros[0], registros[1], registros[2]);
                pQueue.add(NuevoIngreso);
              }
        
              lectorarchivo.close();
        
            } catch (Exception e) {
              System.out.println("Ha ocurrido un error con la lectura del archivo de registros");
              System.exit(1);
            }
            Iterator <Paciente> iterator = pQueue.iterator();
 
            while (iterator.hasNext()) {
                System.out.print(iterator.next());
            }
          /*
          * Si el usuario escoge la opción 3, el programa termina
          */ 
          } else if (opcion.equals("3")){
            System.out.println("Gracias por utilizar nuestro servicios, feliz dia\n");
            verificador = false;
          } else {
            System.out.println("Lo sentimos, fuera de rango");
          }
        }
      } catch (Exception e) {
        System.out.println("Ha ocurrido un error, lo sentimos");
      }

      scan.close();
    }

  /**
  * Método leerArchivo
  * Se lee el contenido del archivo y se guardan los "pacientes" en un VectorHeap
  * @param nombreArchivo: Recibe el nombre del archivo 
  * @return: VectorHeap con las lineas del archivo
  */
  public static VectorHeap<Paciente> leerArchivo(){

    VectorHeap<Paciente> VH = new VectorHeap<Paciente>();

    try {
      
      File archivo = new File("Pacientes.txt");
      Scanner lectorarchivo = new Scanner(archivo);

      while(lectorarchivo.hasNextLine()){

        /**
         * Se crean los "pacientes" y se agregan al VectorHeap
         */
        String informacion = lectorarchivo.nextLine();
        String[] registros = informacion.split(", ");
        Paciente NuevoIngreso = new Paciente(registros[0], registros[1], registros[2]);
        VH.add(NuevoIngreso);
      }

      lectorarchivo.close();

    } catch (Exception e) {
      System.out.println("Ha ocurrido un error con la lectura del archivo de registros");
      System.exit(1);
    }
    return VH;
  }
}
