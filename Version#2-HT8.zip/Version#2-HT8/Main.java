/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * HT8-Sistema de Hospital
 * @author Christopher García - 20541
 * @version 1
 * Se tomaron referencias de ejemplos vistos en clase y material de apoyo
 */
/**
 * Imports
 */
import java.util.*;
import java.io.*;

public class Main {
    
    public static void main(String[] args) {
    
      Scanner scan = new Scanner(System.in);

      System.out.println("\n\t\t|---------------------------------|");
      System.out.println("\t\t|       Hospital Bienaventura     |");
      System.out.println("\t\t|---------------------------------|\n");

      System.out.println("Tengo entendido que necesitas ver los registros");
      System.out.println("Necesito una eleccion del tipo de proceso que se utilizara");
      System.out.println();
      boolean verificador = true;
      try {
        while (verificador){
          System.out.println("\t\t\nTipos de procesos\n");
          System.out.println("1) Implementando PriorityQueue con VectorHeap");
          System.out.println("2) Implementando PriorityQueue con JCF");
          System.out.println("3) Salir\n");
          System.out.print("Tipo de proceso: ");
          String opcion = scan.nextLine();

          if (opcion.equals("1")){
            VectorHeap<Paciente> VH = leerArchivo();
            System.out.println();
            System.out.println("Registro de emergencias");
            VH.OrdenCasos();
            System.out.println();

          } else if (opcion.equals("2")){
            PriorityQueue<Paciente> pQueue = new PriorityQueue<Paciente>();
            try {
      
              File archivo = new File("Pacientes.txt");
              Scanner lectorarchivo = new Scanner(archivo);
        
              while(lectorarchivo.hasNextLine()){
        
                String informacion = lectorarchivo.nextLine();
                String[] registros = informacion.split(", ");
                Paciente NuevoIngreso = new Paciente(registros[0], registros[1], registros[2]);
                pQueue.add(NuevoIngreso);
              }
        
              lectorarchivo.close();
        
            } catch (Exception e) {
              System.out.println("Ha ocurrido un error con la lectura del archivo de registros");
              System.exit(1);
            }
            Iterator <Paciente> iterator = pQueue.iterator();
 
            while (iterator.hasNext()) {
                System.out.print(iterator.next());
            }
            
          } else if (opcion.equals("3")){
            System.out.println("Gracias por utilizar nuestro servicios, feliz dia\n");
            verificador = false;
          } else {
            System.out.println("Lo sentimos, fuera de rango");
          }
        }
      } catch (Exception e) {
        System.out.println("Ha ocurrido un error, lo sentimos");
      }

      scan.close();
    }

  /**
  * Método leerArchivo
  * Se lee el contenido del archivo y se guarda en un ArrayList
  * @param nombreArchivo: Recibe el nombre del archivo 
  * @return: Arraylist con las lineas del archivo
  */
  public static VectorHeap<Paciente> leerArchivo(){

    VectorHeap<Paciente> VH = new VectorHeap<Paciente>();

    try {
      
      File archivo = new File("Pacientes.txt");
      Scanner lectorarchivo = new Scanner(archivo);

      while(lectorarchivo.hasNextLine()){

        String informacion = lectorarchivo.nextLine();
        String[] registros = informacion.split(", ");
        Paciente NuevoIngreso = new Paciente(registros[0], registros[1], registros[2]);
        VH.add(NuevoIngreso);
      }

      lectorarchivo.close();

    } catch (Exception e) {
      System.out.println("Ha ocurrido un error con la lectura del archivo de registros");
      System.exit(1);
    }
    return VH;
  }
}
